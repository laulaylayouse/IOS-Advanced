//
//  CancelButtonDelegate.swift
//  Bucket List
//
//  Created by administrator on 12/12/2021.
//

import UIKit

protocol CancelButtonDelegate: AnyObject{
    func CancelButtonPressed(by controller : UIViewController)
}
