//
//  ViewController.swift
//  Movie Quotes
//
//  Created by administrator on 27/12/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

