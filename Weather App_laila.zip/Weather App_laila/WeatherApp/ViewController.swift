//
//  ViewController.swift
//  WeatherApp
//
//  Created by administrator on 24/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    let days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
    
    @IBOutlet weak var cityname: UILabel!
    @IBOutlet weak var main: UILabel!
    @IBOutlet weak var weatherDis: UILabel!
    @IBOutlet weak var details: UILabel!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var mainTemp: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var weatherInfo : Welcome?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        
        let url = URL(string:"http://api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=34b3eccdc86ab405aa9f10ef3271e01a")
        let session = URLSession.shared
        
        let task = session.dataTask(with: url! , completionHandler : {
            data, response, error in
            print("in here")
            print(data ?? "no data")
            
            guard let myData = data else {return}
            do{
                
                let jsond = try JSONDecoder().decode(Welcome.self, from: myData)
                 self.weatherInfo = jsond
       
                let more = jsond.weather
                
                DispatchQueue.main.async {
                    
                    self.collectionView.reloadData()
                    
                    self.cityname.text = "\(self.weatherInfo?.name ?? "" ) " + "\(self.weatherInfo?.sys.country ?? "" ) Weather "
                    self.main.text = "\(more[0].weatherDescription)"

                    self.weatherDis.text = "\(more[0].main) "
                    self.mainTemp.text = " \(Int(self.weatherInfo?.main.temp ?? 0.0)) K "

                    self.temp.text = "Max: \(Int(self.weatherInfo?.main.tempMax ?? 0.0 )) K    Min: \(Int(self.weatherInfo?.main.tempMin ?? 0.0 )) K "
                    
                    self.details.text = "wind speed :\(self.weatherInfo?.wind.speed ?? 0.0)\nhumidity : \(self.weatherInfo?.main.humidity ?? 0 ) \nfeelsLike: \(self.weatherInfo?.main.feelsLike ?? 0)  \npressure: \(self.weatherInfo?.main.pressure ?? 0 ) "
                }
    
            }catch{
                print(error.localizedDescription)
            }
        })
       
        task.resume()
    }
}
extension ViewController : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return days.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.backgroundColor = .gray
        cell.daylabel.text = days[indexPath.item]
        cell.dayTemp.text = "\(Int(self.weatherInfo?.main.tempMax ?? 0.0 )) k\nmax: \(Int(self.weatherInfo?.main.tempMax ?? 0.0 )) k\nmin: \(Int(self.weatherInfo?.main.tempMin ?? 0.0 )) k"
        
        return cell
    }
}


