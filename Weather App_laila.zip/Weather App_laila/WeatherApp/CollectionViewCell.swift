//
//  CustomCollectionViewCell.swift
//  WeatherApp
//
//  Created by Maha saad on 18/05/1443 AH.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var daylabel: UILabel!
    @IBOutlet weak var dayTemp: UILabel!
}
