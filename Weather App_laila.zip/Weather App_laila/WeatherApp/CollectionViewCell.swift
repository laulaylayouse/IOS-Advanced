//
//  CustomCollectionViewCell.swift
//  WeatherApp
//
//  Created by administrator on 24/12/2021.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var daylabel: UILabel!
    @IBOutlet weak var dayTemp: UILabel!
}
